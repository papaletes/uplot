export const rateLimitConfig = {
  maxRetries: 5,
  baseDelay: 2000,
  maxDelay: 10000,
  requestsPerMinute: 15,
  intervalBetweenCycles: 15000,
  walletVerificationRetries: 3,
};

export const agents = {
  deployment_Hp4Y88pxNQXwLMPxlLICJZzN: "Professor",
  ddeployment_nC3y3k7zy6gekSZMCSordHu7: "Crypto Buddy",
  deployment_SoFftlsf9z4fyA3QCHYkaANq: "Sherlock",
};

export const groqConfig = {
  apiKey: "your-groq-api-key-here",
  model: "mixtral-8x7b-32768",
  temperature: 0.7,
};
